# Design System Strategy: The Digital Concierge

## 1. Overview & Creative North Star
This design system is built upon the "Digital Concierge" North Star. In the context of TuM2 Owner Product Management, our goal is to bridge the gap between high-stakes operational utility and the refined, anticipatory service of a luxury hotel. 

We move beyond the "SaaS-standard" look by embracing **High-End Editorial** layouts. This means rejecting rigid, boxed-in grids in favor of intentional asymmetry, generous white space, and a reliance on tonal depth rather than structural lines. The interface shouldn't feel like a spreadsheet; it should feel like a curated desk where every tool is placed with purpose.

### The Architectural Vision
*   **Precision over Clutter:** Every pixel must earn its place. High contrast ensures readability, while the "Warm Off-white" background prevents the clinical coldness of pure white.
*   **Layered Sophistication:** We utilize "Tonal Sectioning." Instead of 1px borders, we use subtle shifts in background values to define zones, creating a UI that feels carved rather than drawn.
*   **Intentional Asymmetry:** Use the `display` and `headline` scales to create editorial focal points, allowing content to "breathe" in a way that feels bespoke and premium.

---

## 2. Color & Tonal Architecture
The palette is rooted in professional authority (`primary`) and operational health (`secondary`), balanced by a warm, humanistic base.

### The "No-Line" Rule
**Prohibition:** The use of 1px solid borders for sectioning or containment is strictly forbidden. 
**Execution:** Boundaries must be defined solely through background color shifts. 
*   Place a `surface-container-low` component on a `surface` background.
*   Use a `surface-container-high` for interactive sidebars or utility panels.
*   This creates a "molded" look that feels more expensive and integrated than a framed layout.

### Surface Hierarchy & Nesting
Treat the UI as a series of physical layers. Each layer deeper into the hierarchy should use a progressively higher or lower tier.
*   **Base Layer:** `surface` (#FAF9F7) - The canvas.
*   **In-Page Sections:** `surface-container-low` (#F4F3F1).
*   **Interactive Cards/Floating Elements:** `surface-container-lowest` (#FFFFFF) for maximum "lift" and focus.

### The "Glass & Gradient" Rule
To elevate the "Digital Concierge" feel, floating elements (modals, dropdowns, floating action buttons) should utilize **Glassmorphism**.
*   **Backdrop:** Semi-transparent `surface` colors with a `blur(20px)` effect.
*   **Signature Textures:** For primary CTAs and high-level Hero states, use a subtle linear gradient (Top-Left to Bottom-Right) transitioning from `primary` (#0044AA) to `primary_container` (#0E5BD8). This provides a "soul" to the color that flat hex values cannot achieve.

---

## 3. Typography: Editorial Authority
We use a dual-typeface system to balance character with utility.

*   **Headers (Plus Jakarta Sans):** Our "Voice." It is geometric, modern, and authoritative. Use `display-lg` and `headline-md` with generous tracking adjustments (-0.02em) to create an editorial feel in dashboards.
*   **Body & Labels (Inter):** Our "Tool." It is designed for maximum legibility at small sizes. Use `body-md` for standard text and `label-sm` for technical metadata.

**Hierarchy as Identity:** 
High-contrast typography is non-negotiable. Pair a `headline-lg` in `on_surface` with a `body-md` in `on_surface_variant` to create a clear, sophisticated reading path.

---

## 4. Elevation & Depth
Depth in this system is achieved through **Tonal Layering**, not shadows.

*   **The Layering Principle:** Stack `surface-container` tiers. A `surface-container-lowest` card sitting on a `surface-container-low` background creates a soft, natural lift.
*   **Ambient Shadows:** If a "floating" state is required (e.g., a critical modal), use an ultra-diffused shadow: `Y: 8px, Blur: 32px, Color: on_surface @ 6%`. Never use pure black shadows; always tint the shadow with the `on_surface` tone.
*   **The "Ghost Border" Fallback:** For accessibility in high-density data, a border may be used only if it is a "Ghost Border": `outline_variant` at 15% opacity.
*   **Roundedness:** A consistent `md` (0.75rem / 12px) radius must be applied to all primary containers. Use `xl` (1.5rem) for large hero sections to soften the operational edge.

---

## 5. Component Logic

### Buttons
*   **Primary:** Cobalt Blue (`primary`) with `on_primary` text. Use a 12px (`md`) radius. For the "Signature" version, apply the primary-to-container gradient.
*   **Secondary:** `primary_fixed_dim` background with `on_primary_fixed` text. This provides a soft, accessible alternative for secondary actions.
*   **Tertiary:** No background, `primary` text. Use for low-emphasis actions like "Cancel" or "Learn More."

### Input Fields
*   **Style:** No borders. Use `surface_variant` as a subtle fill. 
*   **Focus State:** A 2px `primary` outline with a subtle `primary_container` glow (blur 4px).
*   **Labels:** Always use `label-md` in `on_surface_variant` sitting 8px above the input.

### Cards & Data Lists
*   **Cards:** Forbid divider lines. Separate content groups using the **Spacing Scale** (e.g., 24px vertical gap) or a subtle shift to `surface-container-high` for the header of the card.
*   **Chips:** Use `secondary_container` with `on_secondary_container` for positive statuses. Use `tertiary_fixed` (Warm Orange) for highlights or "New" notifications.

### The Concierge Feed (Custom Component)
A vertical timeline or activity feed that uses a `primary` vertical stem (2px width, 10% opacity) with `primary` nodes. This reinforces the "operational" nature of owner management while maintaining the "clean" aesthetic.

---

## 6. Do’s and Don’ts

### Do:
*   **Use Whitespace as a Tool:** If a layout feels cluttered, increase the padding. This system relies on "breathing room" to feel premium.
*   **Embrace Tonal Shifts:** Always check if you can separate two areas with color before reaching for a line or a shadow.
*   **Align to the Edge:** Use the `headline` scale to anchor the left side of your compositions, creating a strong vertical axis.

### Don’t:
*   **Don't Use Heavy Shadows:** Anything above 10% opacity is too heavy and breaks the "flat vector" style.
*   **Don't Use 100% Black:** Always use `on_surface` or `on_background` for text to maintain the warmth of the palette.
*   **Don't Use Sharp Corners:** Every interactive element must respect the `0.75rem` (12px) radius to maintain the approachable "Concierge" feel.
*   **Don't Default to Grids:** Occasionally break the grid with an overlapping image or a floating "Accent" (`tertiary`) element to create visual interest.