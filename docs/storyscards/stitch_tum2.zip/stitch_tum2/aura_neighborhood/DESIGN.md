# Design System Specification: Hyperlocal Editorial

## 1. Overview & Creative North Star
The Creative North Star for this design system is **"The Curated Neighborhood."** 

Unlike traditional utility apps that feel like rigid databases, this system treats local information as high-end editorial content. We are moving away from the "grid-of-cards" fatigue toward an experience that feels like flipping through a premium architectural or travel magazine. 

By leveraging **intentional asymmetry**, we break the digital monotony. We use **"Aire" (breathable whitespace)** not just as a gap between elements, but as a structural component that guides the eye. The result is a sophisticated, trustworthy environment that feels "designed" rather than "templated."

---

## 2. Color Architecture: The Tonal Layering Principle
Our palette is rooted in warmth and stability. The core innovation of this system is the complete rejection of the 1px divider line.

### The "No-Line" Rule
Sectioning and containment must be achieved exclusively through background shifts. When moving from a global view to a specific section, use a transition from `surface` (`#FAF9F7`) to `surface-container-low` (`#F4F3F1`). 

### Surface Hierarchy & Nesting
Treat the screen as a physical stack of fine-grain paper. 
- **Surface Lowest (`#FFFFFF`):** Reserved for the most interactive, "floating" elements like high-priority cards or active modals.
- **Surface Base (`#FAF9F7`):** The default canvas for the application.
- **Surface Low (`#F4F3F1`):** Use this for grouping related content (e.g., a "Neighborhood News" feed container).
- **Surface Highest (`#E3E2E0`):** Reserved for utility areas like persistent navigation bars or search headers.

### Signature Textures & Gradients
To ensure the UI feels bespoke, use the **Primary CTA Gradient** (`Linear 135deg: #0044AA to #0E5BD8`) for main actions. This adds a sense of "light" and movement that flat cobalt cannot achieve. 

**The Glass Rule:** For floating navigation or overlays, use `surface_container_lowest` at 80% opacity with a `24px` backdrop blur. This allows the warm tones of the neighborhood content to bleed through, softening the interface.

---

## 3. Typography: Authority & Clarity
We use a high-contrast typographic scale to establish a clear editorial voice.

*   **Display & Headlines (Plus Jakarta Sans):** These are our "Voice." Using Bold/SemiBold weights conveys authority and a modern, geometric friendliness. 
    *   *Visual Tip:* Use `display-lg` for hyperlocal hero headlines with tight letter-spacing (-0.02em) to create a premium, "locked-in" editorial look.
*   **Body & Labels (Inter):** These are our "Utility." Inter provides maximum legibility for neighborhood updates, classifieds, and fine print. Its neutral character balances the expressive nature of Plus Jakarta Sans.

---

## 4. Elevation & Depth
In this system, "depth" is a feeling, not a shadow effect.

*   **The Layering Principle:** Rather than adding a shadow to a card, place a `surface_container_lowest` (#FFFFFF) card on a `surface_container_low` (#F4F3F1) background. The 4-unit hex difference provides all the "lift" required.
*   **Ambient Shadows:** Where floating elements (like a FAB or Popover) are necessary, use an ultra-diffused shadow:
    *   *Values:* `Y: 8px, Blur: 24px, Color: rgba(26, 28, 27, 0.06)`. 
    *   Note that the shadow uses the `on_surface` color, not pure black, to maintain the warm, organic feel.
*   **The "Ghost Border" Fallback:** If accessibility requirements demand a border (e.g., in high-contrast modes), use `outline_variant` (#C3C6D6) at 15% opacity. It should be felt, not seen.

---

## 5. Components

### Buttons & Interaction
*   **Primary Button:** Uses the Primary CTA Gradient. 12px (`md`) radius. Label in `label-md` (Inter SemiBold, All Caps, +0.05em tracking).
*   **Secondary Fixed:** Uses `secondary_fixed_dim` (#80D5CB). This minty-teal provides a sophisticated contrast to the cobalt.
*   **Tertiary "Spark":** Use `tertiary` (#7E3700) or the "Warm Spark" (#FF8D46) for notifications or "New" badges.

### Editorial Cards
*   **Construction:** No borders. 12px corner radius.
*   **Layout:** Embrace asymmetry. Place an image with a `title-lg` headline, but offset the text so it slightly overlaps the image container or hangs into the whitespace.
*   **Separation:** Use `80px` to `120px` of vertical whitespace between major sections instead of divider lines.

### Input Fields
*   **Style:** Fills should be `surface_container_high` (#E9E8E6). On focus, the field should transition to `surface_container_lowest` (#FFFFFF) with a subtle `2px` cobalt "glow" (not a solid stroke).

### Neighborhood Lists
*   **Pattern:** Instead of a list with lines, use alternating tonal blocks or simply wide vertical padding (24px+) between items. Use `label-sm` in `on_surface_variant` (#424654) for metadata.

---

## 6. Do’s and Don’ts

### Do:
*   **Use Asymmetry:** Place a "Featured Event" card at 90% width, aligned to the right, leaving a column of whitespace on the left for "Aire."
*   **Embrace Tonal Shifts:** Layer white cards on off-white backgrounds to create hierarchy.
*   **Prioritize Typography:** Let the size of the headline, not the thickness of a border, tell the user what is important.

### Don't:
*   **Use 1px Lines:** Do not use dividers to separate list items or sections. It breaks the editorial flow.
*   **Use Heavy Shadows:** Avoid "Material Design 2" style shadows. They feel too "app-like" and not enough like "fine print."
*   **Center Everything:** Perfect symmetry feels clinical. Offset your elements to create a sense of human curation.
*   **Overuse the Cobalt:** Use the blue for action and intent; let the warm neutrals do the heavy lifting for the "soul" of the app.